// CppConsoleApplication2.cpp : Defines the entry point for the console application.
//

#include <tchar.h>

int _tmain(int argc, _TCHAR* argv[])
{
	THIS_CODE_DOES_NOT_COMPILE;
	return 0;
}

