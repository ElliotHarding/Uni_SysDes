#pragma once 

__declspec(dllexport) void Hello();