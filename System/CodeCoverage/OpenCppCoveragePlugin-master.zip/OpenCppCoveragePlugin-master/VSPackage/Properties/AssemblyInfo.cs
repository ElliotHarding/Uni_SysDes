﻿using System;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("OpenCppCoverage")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("OpenCppCoverage")]
[assembly: AssemblyProduct("OpenCppCoverage")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]   
[assembly: ComVisible(false)]     
[assembly: CLSCompliant(false)]
[assembly: NeutralResourcesLanguage("en-US")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

[assembly: InternalsVisibleTo("VSPackage_IntegrationTests, PublicKey=00240000048000009400000006020000002400005253413100040000010001008ba749380266d3d6dfefaf54e5b092dc2c01c8e7242cfa335eb27e77200a3906c4d08556487da49cca3504c085a37db8a5e4f35f9e9147b0e7a0f40364f7071056fe67d6c02a4c51363dba75f9bbf27b954f1703c5de2d4e78ff812ec90055c13bba520fbc2241387401dc4ff41044a3afbc0ddc4879eb8abc64aa77ec97e1bb")]
[assembly: InternalsVisibleTo("VSPackage_UnitTests, PublicKey=00240000048000009400000006020000002400005253413100040000010001008ba749380266d3d6dfefaf54e5b092dc2c01c8e7242cfa335eb27e77200a3906c4d08556487da49cca3504c085a37db8a5e4f35f9e9147b0e7a0f40364f7071056fe67d6c02a4c51363dba75f9bbf27b954f1703c5de2d4e78ff812ec90055c13bba520fbc2241387401dc4ff41044a3afbc0ddc4879eb8abc64aa77ec97e1bb")]
[assembly: InternalsVisibleTo("DynamicProxyGenAssembly2, PublicKey=0024000004800000940000000602000000240000525341310004000001000100c547cac37abd99c8db225ef2f6c8a3602f3b3606cc9891605d02baa56104f4cfc0734aa39b93bf7852f7d9266654753cc297e7d2edfe0bac1cdcf9f717241550e0a7b191195b7667bb4f64bcb8e2121380fd1d9d46ad2d92d2d15605093924cceaf74c4861eff62abf69b9291ed0a340e113be11e6a7d3113e92484cf7045cc7")]